import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;

import java.util.Collections;

public class CallProducerConsumer {
    /*public static void main(String[] args) {

        MessageProducer.mainProducer();
        MessageConsumer.mainConsumer();
    }*/
}
