import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.LoggerFactory;

import org.slf4j.Logger;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageConsumer {
    private static final Logger logger =  LoggerFactory.getLogger(MessageConsumer.class);
    String topic = "AKRM";
    KafkaConsumer<String,Object> kafkaConsumer;

    public MessageConsumer(Map<String, Object> stringObjectMap){
        kafkaConsumer = new KafkaConsumer<String, Object>(buildConsumerProps());
    }

    public static Map<String, Object> buildConsumerProps(){
        Map<String,Object> propsMap = new HashMap<>();
        propsMap.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.26.133:7701,192.168.26.134:7701,192.168.26.135:7701");
        propsMap.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        propsMap.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        propsMap.put(ConsumerConfig.GROUP_ID_CONFIG,"messageconsumer");
        return propsMap;
    }

    public void pollKafka(){
        kafkaConsumer.subscribe(Arrays.asList(topic));
        Duration timeOutDuration = Duration.of(100, ChronoUnit.MILLIS);
        while(true){
            try{
                ConsumerRecords<String,Object> consumerRecords = kafkaConsumer.poll(100);
                consumerRecords.forEach((record) ->
                {logger.info("Consumer Record key is : {} with value : {} and partition : {}  and offset : {}",record.key(),record.value(),record.partition(), record.offset());});
            }catch(Exception e){
                logger.error("Exception in pollKafka : {}",e.getMessage());
            }/*finally{
                kafkaConsumer.close();
            }*/
        }


    }
    public static void mainConsumer() {

        MessageConsumer messageConsumer = new MessageConsumer(buildConsumerProps());
        messageConsumer.pollKafka();

    }
}
