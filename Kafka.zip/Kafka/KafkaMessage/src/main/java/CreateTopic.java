import org.apache.kafka.clients.admin.NewTopic;

public class CreateTopic {

    public NewTopic createTopic(){
        NewTopic newTopic = new NewTopic("TopicThree",3,(short)3);
        return newTopic;

    }
}
