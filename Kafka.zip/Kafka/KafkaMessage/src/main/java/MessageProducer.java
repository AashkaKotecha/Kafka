import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MessageProducer {
    private static final Logger logger = LoggerFactory.getLogger(MessageProducer.class);
    static String topic ="AKRM";
    KafkaProducer<String, Object> kafkaProducer;


    public MessageProducer(Map<String, Object> propsMap){
        kafkaProducer = new KafkaProducer<String, Object>(propsMapMethod());
    }

    public static Map<String, Object> propsMapMethod(){
        Map<String,Object> propsMap = new HashMap<>();
        propsMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.26.133:7701,192.168.26.134:7701,192.168.26.135:7701");
        propsMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        propsMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());


        return propsMap;
    }
    Callback callback = new Callback() {
        @Override
        public void onCompletion(RecordMetadata metadata, Exception exception) {
            if(exception!=null){
                logger.error("Error occurred in CallBack from Producer: ", exception.getMessage());
            }else{
                logger.info("Published Message from CallBack with offset number {} to partition {} of topic {}", metadata.offset(),metadata.partition(),metadata.topic());
            }

        }
    };
    public void publishMessageAsync(String key, String value){
        ProducerRecord<String, Object> producerRecord = new ProducerRecord<String,Object>(topic,key,value);
        try {
            kafkaProducer.send(producerRecord,callback).get();

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    public void close(){
        kafkaProducer.close();
    }

    public void publishMessageSync(String key, String value){
        ProducerRecord<String, Object> producerRecord = new ProducerRecord<String,Object>(topic,key,value);
        try {
            RecordMetadata recordMetadata = kafkaProducer.send(producerRecord).get();
           // System.out.println("topic: "+recordMetadata.topic()+" partition: "+recordMetadata.partition()+" offset: "+recordMetadata.offset());
            logger.info("Message : {} : sent successfully for the key {}",value,key);
            logger.info("Published Message offset number {} to partition {} of topic {}", recordMetadata.offset(),recordMetadata.partition(),recordMetadata.topic());
        } catch (InterruptedException | ExecutionException e) {
            //e.printStackTrace();
            logger.error("Exception in publishMessageSync : {}",e.getMessage());
        }
    }

    public static void mainProducer() {
        /*CreateTopic ct = new CreateTopic();
        NewTopic topicName = ct.createTopic();
        AdminClient adminClient = AdminClient.create(MessageProducer.propsMapMethod());
        adminClient.createTopics(Collections.singleton(topicName));
        topic=topicName.name();*/

        MessageProducer messageProducer = new MessageProducer(propsMapMethod());

        //messageProducer.publishMessageSync(null,"Sending New message from Java Code");
       /* messageProducer.publishMessageAsync(null,"Sending New message from Java Code using Async method");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
       /* messageProducer.publishMessageSync("key1","Message 1 with key1");
        messageProducer.publishMessageSync("key1","Message 2 with key1");
        messageProducer.publishMessageSync("key1","Message 3 with key1");*/
        messageProducer.publishMessageSync("9","Message 1 with 9");
        messageProducer.publishMessageSync("9","Message 2 with 9");
        messageProducer.publishMessageSync("99","Message 1 with 99");
        messageProducer.publishMessageSync("99","Message 2 with 99");



    }


}
