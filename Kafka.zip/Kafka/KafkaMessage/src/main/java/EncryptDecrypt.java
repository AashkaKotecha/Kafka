

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.security.spec.KeySpec;
import java.util.Scanner;

public class EncryptDecrypt {

    public static String encrypt(String unencryptedString, String code,String date) {
        String encryptedString = null;
        String UNICODE_FORMAT = "UTF8";
        final String DESEDE_ENCRYPTION_SCHEME = "DESede";
        KeySpec ks;
        SecretKeyFactory skf;
        Cipher cipher;
        byte[] arrayBytes;
        String myEncryptionKey;
        String myEncryptionScheme;
        SecretKey key;

        try {
            myEncryptionKey =code+date+"SentinelEncryptKey";
            System.out.println("My encryption key: "+myEncryptionKey);
            myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
            arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
            ks = new DESedeKeySpec(arrayBytes);
            skf = SecretKeyFactory.getInstance(myEncryptionScheme);
            cipher = Cipher.getInstance(myEncryptionScheme);
            key = skf.generateSecret(ks);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
            byte[] encryptedText = cipher.doFinal(plainText);
            encryptedString = new String(Base64.encodeBase64(encryptedText));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedString;
    }


    public static String decrypt(String encryptedString, String code,String date) {
        String decryptedText=null;
        String UNICODE_FORMAT = "UTF8";
        final String DESEDE_ENCRYPTION_SCHEME = "DESede";
        KeySpec ks;
        SecretKeyFactory skf;
        Cipher cipher;
        byte[] arrayBytes;
        String myEncryptionKey;
        String myEncryptionScheme;
        SecretKey key;
        try {
        myEncryptionKey =code+date+"SentinelEncryptKey";
        System.out.println("My encryption key: "+myEncryptionKey);
        myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
        arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
        ks = new DESedeKeySpec(arrayBytes);
        skf = SecretKeyFactory.getInstance(myEncryptionScheme);
        cipher = Cipher.getInstance(myEncryptionScheme);
        key = skf.generateSecret(ks);

            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] encryptedText = Base64.decodeBase64(encryptedString);
            byte[] plainText = cipher.doFinal(encryptedText);
            decryptedText= new String(plainText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryptedText;
    }



    public static void main(String args []) throws Exception
    {

//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter Client name : ");
//        String clientName = scanner.next();
//        System.out.println("Enter trade date : ");
//        String tradeDate = scanner.next();
        /*long startTimeTotal = System.currentTimeMillis();
        for(int i=0;i<2000;i++) {
            long startTime = System.currentTimeMillis();
           String encrypted =   EncryptDecrypt.encrypt("Zerodha corp"+i,"Zerodha"+i, "Jan2022");
            System.out.println("Encrypted String:" + encrypted);

            String decrypted = EncryptDecrypt.decrypt(encrypted,"Zerodha"+i, "Jan2022");
            System.out.println("Decrypted String:" + decrypted);

            long endTime = System.currentTimeMillis();
            System.out.println("Took " + (endTime - startTime) + " milliseconds");



        }
        long endTimeTotal = System.currentTimeMillis();
        System.out.println("Took " + (endTimeTotal - startTimeTotal) + " milliseconds");*/
     System.out.println("CMID:  "+EncryptDecrypt.decrypt("rrP1qvjItbw=","BuyerClearingMemberId","January2022"));

        System.out.println("TMID:  "+EncryptDecrypt.decrypt("C62SPoUDszs=","BuyerTradeMemberId","January2022"));




    }


}
