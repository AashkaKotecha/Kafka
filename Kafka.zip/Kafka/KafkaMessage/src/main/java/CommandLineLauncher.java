import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class CommandLineLauncher {
    private static final Logger logger =  LoggerFactory.getLogger(CommandLineLauncher.class);
    static  Scanner scanner;

    public static Map<String, Object> propsMapMethod(){
        Map<String,Object> propsMap = new HashMap<>();
        propsMap.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.26.133:7701,192.168.26.134:7701,192.168.26.135:7701");
        propsMap.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        propsMap.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());


        return propsMap;
    }

    public static MessageProducer init(){
        Map<String, Object> producerProps = propsMapMethod();
        MessageProducer messageProducer = new MessageProducer(producerProps);
        return  messageProducer;
    }
    public static void launchCommandLine() {
        boolean cliUp = true;
        while (cliUp){
            userOptions();
            scanner   = new Scanner(System.in);
            String option = scanner.next();
            System.out.println("Selected Option is : {} "+ option);

            switch (option) {
                case "1":
                    acceptMessageFromUser(option);
                    break;
                case "2":
                    cliUp = false;
                    break;
                default:
                    break;

            }
        }
    }

    public static void acceptMessageFromUser(String option) {

        Scanner scanner = new Scanner(System.in);
        boolean flag = true;
        while(flag){
            System.out.println("Please enter a message to Produce to Kafka:");
            String input = scanner.nextLine();
            logger.info("Entered message to produce is: {}",input);
            if(input.equals("00")){
                flag=false;
            }else{
                MessageProducer messageProducer = init();
                publishMessage(messageProducer,input);
                messageProducer.close();

            }
            logger.info("Exiting from Option: {}",option);
        }


    }

    public static void publishMessage(MessageProducer messageProducer, String input) {
        StringTokenizer stringTokenizer = new StringTokenizer(input,"-");
        Integer noOfTokens = stringTokenizer.countTokens();
        switch (noOfTokens){
            case 1 : messageProducer.publishMessageSync(null,stringTokenizer.nextToken());
            break;
            case 2 :  messageProducer.publishMessageSync(stringTokenizer.nextToken(),stringTokenizer.nextToken());
            break;
            default:break;
        }
    }



    public static void userOptions() {
        List<String> userInputList = new ArrayList<String>();
        userInputList.add("1 : KafkaProducer");
        userInputList.add("2 : Exit");
        System.out.println("Please select an option from below: ");
        for(String userInput : userInputList){
            System.out.println(userInput);
        }
    }

    public static void main(String[] args) {
        System.out.println("********************************************************************");
        System.out.println("WELCOME TO COMMAND LINE LAUNCHER");
        System.out.println("********************************************************************");

        launchCommandLine();

        System.out.println("********************************************************************");
        System.out.println("BYE!!!!!!!!!!");
        System.out.println("********************************************************************");

    }
}
